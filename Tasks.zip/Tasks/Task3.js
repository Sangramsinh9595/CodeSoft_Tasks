let currentInput = '';
let operator = '';
let firstValue = '';

function appendNumber(num) {
    currentInput += num;
    document.getElementById('display').value = currentInput;
}

function setOperator(op) {
    firstValue = currentInput;
    currentInput = '';
    operator = op;
}

function calculate() {
    if (firstValue && operator && currentInput) {
        let result;
        if (operator === '+') {
            result = parseFloat(firstValue) + parseFloat(currentInput);
        } else if (operator === '-') {
            result = parseFloat(firstValue) - parseFloat(currentInput);
        }
        document.getElementById('display').value = result;
        currentInput = result;
        operator = '';
        firstValue = '';
    }
}